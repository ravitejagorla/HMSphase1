# num=7654321
# rev=0
# while num!=0:
#     digit=num%10
#     rev=rev*10+digit
#     num=num//10
# print("reversed num",rev)


# str="kavyasrii"
# print(str[::-1])

row=int(input("enter the rows:"))
for i in range(1,row+1):
    print(" "*(row-1),end="")
    print("*"*i)

